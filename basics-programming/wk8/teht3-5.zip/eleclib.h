#ifndef __ELECLIB_INCLUDED__
#define __ELECLIB_INCLUDED__

float getResistorCurrent(float voltage, float resistance);
void printRequiredFuse(float power);

#endif // #ifndef __ELECLIB_INCLUDED__
