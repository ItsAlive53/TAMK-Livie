#define PI 3.14159

// examples
void tulostus();

double circleArea(double radius);
// END examples

int square(int x);

int rectArea(int w, int h);

double tripPrice(double km, double gasUse, double gasPrice);

int wage(int hours);
